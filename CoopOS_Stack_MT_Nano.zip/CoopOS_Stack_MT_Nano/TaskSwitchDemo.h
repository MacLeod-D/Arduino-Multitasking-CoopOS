
#define STACKALLOC 765

#define IDLE_STLEN 75
#define MAX_TASKS 8



typedef void (* FuncPt) (void);                             // Function pointer

enum State  { BLOCKED, READY};                              // State of task
enum State2  { NON, RDY, RUN, DEL, BLK };                   // SubState of task
char *State2Txt[] = { "NON", "RDY", "RUN", "DEL", "BLK" };  // for future enhencements


struct task {
    char* name;                                             // Name of task
    FuncPt function;                                        // Pointer to function of this task
    uint8_t prio;                                           // priority of task, only relative value are used
    uint16_t sp_save;                                       // value of stack pointer when switched
    uint16_t task_stack;                                    // pointer to stack of this task
    uint16_t stackLen;                                      // length of stack for this task
    char     new_task;                                      // always true except Idle
    unsigned long lastCalled;                               // last time called in µs
    unsigned long Delay;                                    // Delay in µs
    State   state;                                          // State of task (READY, BLOCKED)
    State2  state2;                                         // Substate of task (sa.)
};

//-----------------------------Globals-----------------------------------
// for multitasking
char *STACK;
uint8_t number_of_tasks;                                    // used and set by Init()
volatile uint8_t current_task=0;                            // Task running
unsigned int FirstSP;                                       // StackPtr at Start
volatile struct task Tasks[MAX_TASKS];                      // All info to the single tasks
unsigned int StackLow;                                      // Max. used for Stack
unsigned int StackHi;                                       // Max. used for Stack

// for tasks
char DisplayUsed=0;                                         // As Mutex:
unsigned int IdleCount;                                     // Incremented by Idle
unsigned int BlinkCount;                                    // Incremented by task 1 
unsigned int SwitchCount;                                   // Yield calls
uint8_t      T7Handle;                                      // Wake from interrupt



#define StartMultiTasking() \
 SP=STACK;\
 Tasks[0].function ();  // start task0==idle and that starts all
                          // declared tasks. Idle will never stop 

// found elsewhere
/*
 push  r1
 1a0: 0f 92         push  r0
 1a2: 0f b6         in  r0, 0x3f  ; 63
 1a4: 0f 92         push  r0
 1a6: 11 24         eor r1, r1
 push r18
 1aa: 3f 93         push  r19
 1ac: 4f 93         push  r20
 1ae: 5f 93         push  r21
 1b0: 6f 93         push  r22
 1b2: 7f 93         push  r23
 1b4: 8f 93         push  r24
 1b6: 9f 93         push  r25
 1b8: af 93         push  r26
 1ba: bf 93         push  r27
 1bc: ef 93         push  r30
 1be: ff 93         push  r31


 lds r30, 0x0100
 1c4: f0 91 01 01   lds r31, 0x0101
 1c8: 09 95         icall


 ff 91        pop r31
 1cc: ef 91         pop r30
 1ce: bf 91         pop r27
 1d0: af 91         pop r26
 1d2: 9f 91         pop r25
 1d4: 8f 91         pop r24
 1d6: 7f 91         pop r23
 1d8: 6f 91         pop r22
 1da: 5f 91         pop r21
 1dc: 4f 91         pop r20
 1de: 3f 91         pop r19
 1e0: 2f 91         pop r18
 1e2: 0f 90         pop r0
 1e4: 0f be         out 0x3f, r0  ; 63
 1e6: 0f 90         pop r0
 1e8: 1f 90         pop r1
 1ea: 18 95         reti
*/



/**********************************************************************
*
*  Assembler macros
*
**********************************************************************/

/*  as found in ChibiOS: et al. */

#define pushall() asm volatile \
  (               \
    "push r2  \n\t"   \
    "push r3  \n\t"   \
    "push r4  \n\t"   \
    "push r5  \n\t"   \
    "push r6  \n\t"   \
    "push r7  \n\t"   \
    "push r8  \n\t"   \
    "push r9  \n\t"   \
    "push r10 \n\t"   \
    "push r11 \n\t"   \
    "push r12 \n\t"   \
    "push r13 \n\t"   \
    "push r14 \n\t"   \
    "push r15 \n\t"   \
    "push r16 \n\t"   \
    "push r17 \n\t"   \
    "push r28 \n\t"   \
    "push r29 \n\t"   \
  )

#define popall() asm volatile \
  (               \
    "pop r29 \n\t"      \
    "pop r28 \n\t"      \
    "pop r17 \n\t"      \
    "pop r16 \n\t"      \
    "pop r15 \n\t"      \
    "pop r14 \n\t"      \
    "pop r13 \n\t"      \
    "pop r12 \n\t"      \
    "pop r11 \n\t"      \
    "pop r10 \n\t"      \
    "pop r9  \n\t"      \
    "pop r8  \n\t"      \
    "pop r7  \n\t"      \
    "pop r6  \n\t"      \
    "pop r5  \n\t"      \
    "pop r4  \n\t"      \
    "pop r3  \n\t"      \
    "pop r2  \n\t"      \
  )

/**********************************************************************
*
* Kernel
*
**********************************************************************/

/*  pause() and resume() are used to quickly skip tasks that are blocked,
  in this demo they are blocked by being delayed. */
void stopMe() {
  Tasks[current_task].state=BLOCKED;
  Tasks[current_task].state2=BLK;
  
}

void stop_task (uint8_t tn)
{
  Tasks[tn].state = BLOCKED;
  Tasks[tn].state2=BLK;
}

void resume_task (uint8_t tn)
{
  Tasks[tn].state = READY;
  Tasks[tn].state2 = RDY;
}





/**
 * @brief TaskSwitch
 * 
 * @details
 * TaskSwitch is called by Yield() [ Delay()]
 * It saves the state of the running task and switch to newer task
 */

inline void TaskSwitch (uint8_t old, uint8_t newer)
{
  // Save old
  cli();
  pushall();
  Tasks[old].sp_save = SP;
  
  sei();
  while (1)
  {

    current_task=newer;
    
    if (Tasks[current_task].new_task == true)               // a task marked as NEW should be installed
    {                                                       // the running task has save it's context (s.a)
     // All tasks in Init(...); will come to this point
     // at first run. All initialisation before while(1) are wil be done now
      cli();
      Tasks[current_task].new_task = false;
      SP = Tasks[current_task].task_stack;                  // set SP to the new task. It will save it's stack when Yielded
      //BITCLEARD6;
      sei();
      Tasks[current_task].function ();                      // run the new task. It should not return ( starting a while(1)-loop)
  
      // a task has ended!
      Tasks[current_task].state = BLOCKED;                  // all finished task ( jumped out of while(1) ) will end here
      Tasks[current_task].new_task == true;                 // if resumed they start again
    }
    else
    {
      // this task had been started and has save stack      // Yield had select the next task
      cli();                                                // switch to the SP of this task, own stack is saved (s.a. pushall )
      SP = Tasks[current_task].sp_save;                     // switch the stack to the save stackpt of next task to execute
      sei();
  
      popall();                                             // pop saved registers and return -> goto last Yield-Point of switched out task
      //BITCLEARD6;
      return;
    }
  }
}






// This function is called from the task to give up CPU
// If mics >0 then the task ist delayed (micro seconds)

/**
 * @brief Yield() is the Scheduler
 * 
 * @details
 * Yield() is called by Yield(0) and Delay(micros)
 * Yield decides which task should run next and start that task
 * via TaskSwitch(old, new)
 */
void Yield(unsigned long mics) {
unsigned long m=micros();
struct task *tp, *tp2;
  SwitchCount++;
  //BITSETD6;
  tp=&Tasks[current_task];
  tp->lastCalled=m;

Start:

  if (current_task==0) {                                        // idle
    Tasks[0].state2=RDY ;
    ///MySerial.print("Task 0 : ");
    for (int i=1; i < MAX_TASKS; i++) {
      
      tp2=&Tasks[i];
      //if (Tasks[i].stopped==1) {   
      if (Tasks[i].state==BLOCKED) {
        ///MySerial.println(i);
        if (Tasks[i].Delay) {
          if ((m-tp2->lastCalled)>=Tasks[i].Delay) {
            
            //tp2->stopped=0;
            tp2->Delay=0;
            tp2->state=READY;
            tp2->state2=RDY;
            
            ///MySerial.print("-------------------------to Ready: "); slow=1;
            ///MySerial.println(i);
           // while(1);
          }  
        }
      
         
       
      //MySerial.println(i);
      
      }
    }
  }
  else {
    ///MySerial.print("Delay: "); MySerial.println(mics);
    //Tasks[current_task].lastCalled=micros();
    if (tp->state==READY) {
      if (mics>0) {
        tp->Delay=mics;
        //tp->stopped=1;
        tp->state = BLOCKED;
        tp->state2 = DEL;
      }
    }
  }  
 


  // Search for the next task
  int prio=0;
  int oldTask=current_task;
//  do
//  {
//      /*  Circle through the tasks, the if() construct is much
//        faster than using a mod % operator. */
//      if (++current_task == number_of_tasks)
//        current_task = 0;
//
//    /*  Skipping inactive tasks.  It is not uncommon for the system
//      to spend most of it's time chasing its tail going through a
//      list of all inactive tasks.  This is a good place to add code
//      for putting the processor in a low power state.  It is also
//      a good place to modulate an output pin to make a PWM measurement
//      of processor loading. */
//  } while (Tasks[current_task].state == BLOCKED);

  oldTask=current_task;
  char HiPrio=0, HiNum=0;
  extern char number_of_tasks;
  for (int i=1 /* not Idle */; i < number_of_tasks; i++) {
    if (Tasks[i].state== READY) {
       if (Tasks[i].prio > HiPrio) {
         HiPrio=Tasks[i].prio;
         HiNum=i;
       }
    }
  }
  current_task=HiNum;
  

  if (oldTask==current_task) {
    tp->state=READY;
    tp->state2=RUN;
    //BITCLEARD6;
    // no TaskSwitch needed
    return;
  }
  else { 
    //current_task=oldTask;
    //Tasks[oldTask].state=BLOCKED;
    Tasks[current_task].state=READY;
    Tasks[current_task].state2=RUN;
    
    TaskSwitch(oldTask, current_task);
  }
}


extern void Idle();
int freeRam();



/**
 * @brief TaskInit() fills the Table of Tasks to start
 * 
 * @details
 * Yield() is called by Yield(0) and Delay(micros)
 * Yield decides which task should run next and start that task
 * via TaskSwitch(old, new)
 */


//       NAME   FUNCTION    STCK-LEN  PRIO  DELAY STATE  
uint8_t TaskInit(char* _name,
    FuncPt _function,
    int16_t _stackLen,
    uint8_t _prio,
    unsigned long _delay,
    State _state) 

{
static int task_num=0;
//static int StackPt=STACK;
extern int __heap_start, *__brkval; 
  if (task_num>=MAX_TASKS) {
    //MySerial.println(F("INIT: MAX_TASKS OVERFLOW:"));
    Serial.println("INIT: MAX_TASKS OVERFLOW:");
    Serial.println(_name);
    while(1);
  }

  // auto-create idle task task0
  if (task_num==0) {
    //TaskInit("T0", task0, 0, St_len, false , 0, READY);
    Tasks[task_num].name = "Idle";
    Tasks[task_num].function = Idle;
    Tasks[task_num].prio = 0;
    Tasks[task_num].stackLen=IDLE_STLEN;

    if (freeRam<100) {
      //MySerial.println(F("FreeRam < 100 Bytes !!!"));
      Serial.println(F("FreeRam < 100 Bytes !!!"));
      while(1);
    }
   
    Tasks[task_num].task_stack = STACK;
    Tasks[task_num].stackLen = IDLE_STLEN;
    
    Tasks[task_num].new_task = false;
    Tasks[task_num].lastCalled = micros();
    Tasks[task_num].Delay = 0;
    Tasks[task_num].state = READY;
    Tasks[task_num].state2 = RDY;
    
    task_num++;
    number_of_tasks=task_num;
    StackPt-=IDLE_STLEN;

//    Serial.println((int)StackLow);
//    Serial.println((int)IDLE_STLEN);
//    Serial.println((int)StackPt);
    Serial.print("Idle"); Serial.print(-IDLE_STLEN); Serial.print(F(": Stack free for next task: ")); Serial.println((int)(StackPt-StackLow));
  
  }
  

  Tasks[task_num].name = _name;
  Tasks[task_num].function = _function;
  Tasks[task_num].prio = _prio;
  //Tasks[task_num].task_stack = _task_stack;
  Tasks[task_num].task_stack = StackPt;
  StackPt-=_stackLen;
  Tasks[task_num].stackLen=_stackLen;
  
  if ( StackPt < StackLow ) {
    //MySerial.println(F("ERROR: STACK too small !"));
    Serial.println(F("ERROR: STACK too small !"));
    while(1);
  }

  //Serial.println((int)_stackLen);
  //Serial.println((int)StackPt);
  Serial.print(_name);  Serial.print(-_stackLen); Serial.print(F(": Stack free for next task: ")); Serial.println((int)(StackPt-StackLow));
  
  
  Tasks[task_num].new_task = true;
  Tasks[task_num].lastCalled = micros();
  Tasks[task_num].Delay = _delay;
  if (_delay != 0) _state=BLOCKED;
  Tasks[task_num].state = _state;
    
  task_num++;
  number_of_tasks=task_num;
  return task_num-1;

}




int freeRam () 
{
  extern int __heap_start, *__brkval; 
  int v; 
  return (int) &v - (__brkval == 0 ? (int) &__heap_start : (int) __brkval); 
}

void Idle() {
  while(1) {
    Yield(0);
  }
  
}

#define Delay(x) Yield(x);




 // Alloc the stack for tasks:
#define StackInit() \
  STACK=malloc(STACKALLOC+1);\ 
  StackLow=STACK;\
  StackHi=STACK+STACKALLOC;\
  STACK  =STACK+STACKALLOC;\
  if (STACK==NULL) { \
    Serial.println(F("ERROR: Not enough room for Stack !!!"));\
    while(1);\
  }\
  Serial.print(F("\n\nStack allocated: ")); Serial.println(STACKALLOC);\
  Serial.print(F("Free Ram now   : ")); Serial.println(freeRam());\
  Serial.println();





