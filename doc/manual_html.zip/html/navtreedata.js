var NAVTREE =
[
  [ "CoopOS_Stack_MT_Nano", "index.html", [
    [ "What does this program ?", "index.html", [
      [ "All Demos as ZIP-files:", "index.html#intro_sec", null ]
    ] ],
    [ "Doxyfile", "md_Doxyfile.html", null ],
    [ "Introduction", "intro.html", null ],
    [ "Overview", "over.html", null ],
    [ "Getting started", "start.html", null ],
    [ "Intertask Communication", "comm.html", null ],
    [ "Initializing Tasks", "init.html", null ],
    [ "Tools", "tools.html", [
      [ "Serial Output", "tools.html#serout", null ],
      [ "Pins", "tools.html#pins", null ],
      [ "Show Stack", "tools.html#showst", null ],
      [ "Functions to check stackspace", "tools.html#stackFree", null ],
      [ "WatchDogTimer", "tools.html#wdt", null ],
      [ "Interrupts", "tools.html#inter", null ],
      [ "Debug / Breakpoints", "tools.html#break", null ]
    ] ],
    [ "The Program", "prog.html", null ],
    [ "Conclusion", "conc.html", null ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"CoopOS__Stack__MT__Nano_8ino.html",
"classmySerial.html#ac70023a022733cd5ab3a131e67156ca9"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';