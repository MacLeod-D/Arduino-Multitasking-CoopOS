var Task_8h =
[
    [ "task", "structtask.html", "structtask" ],
    [ "FuncPt", "Task_8h.html#a80a65ff2a912daf1738fc13a83f8b238", null ],
    [ "State", "Task_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8", [
      [ "BLOCKED", "Task_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a376c1b6a3f75d283a2efacf737438d61", null ],
      [ "READY", "Task_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a6564f2f3e15be06b670547bbcaaf0798", null ],
      [ "BLOCKED", "TaskSwitchDemo_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a376c1b6a3f75d283a2efacf737438d61", null ],
      [ "READY", "TaskSwitchDemo_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a6564f2f3e15be06b670547bbcaaf0798", null ]
    ] ],
    [ "State2", "Task_8h.html#aa279f78236faac6b561f1d6589355a30", [
      [ "NON", "Task_8h.html#aa279f78236faac6b561f1d6589355a30a7905fcd753e9915a521ea77aa7066415", null ],
      [ "RDY", "Task_8h.html#aa279f78236faac6b561f1d6589355a30a79574f1d0a2f78eff42042e34b72436d", null ],
      [ "RUN", "Task_8h.html#aa279f78236faac6b561f1d6589355a30a439c688a4e9ed31638d5922a50680a8e", null ],
      [ "DEL", "Task_8h.html#aa279f78236faac6b561f1d6589355a30a11563127ec3be864b514a1784c5d37a6", null ],
      [ "BLK", "Task_8h.html#aa279f78236faac6b561f1d6589355a30ae71455800b2dce1edd5dffc06a904e53", null ],
      [ "NON", "TaskSwitchDemo_8h.html#aa279f78236faac6b561f1d6589355a30a7905fcd753e9915a521ea77aa7066415", null ],
      [ "RDY", "TaskSwitchDemo_8h.html#aa279f78236faac6b561f1d6589355a30a79574f1d0a2f78eff42042e34b72436d", null ],
      [ "RUN", "TaskSwitchDemo_8h.html#aa279f78236faac6b561f1d6589355a30a439c688a4e9ed31638d5922a50680a8e", null ],
      [ "DEL", "TaskSwitchDemo_8h.html#aa279f78236faac6b561f1d6589355a30a11563127ec3be864b514a1784c5d37a6", null ],
      [ "BLK", "TaskSwitchDemo_8h.html#aa279f78236faac6b561f1d6589355a30ae71455800b2dce1edd5dffc06a904e53", null ]
    ] ],
    [ "StackPrepare", "Task_8h.html#af55d11391fca3dd7c3579f1d4842d198", null ],
    [ "current_task", "Task_8h.html#a9f471ed1586651af36428513ada2706b", null ],
    [ "FirstSP", "Task_8h.html#ace91e478b51bbc73971919b539fccb38", null ],
    [ "IdleCount", "Task_8h.html#ac3f24db1f52f0fd6d2be8034eb1e38d6", null ],
    [ "number_of_tasks", "Task_8h.html#af3d271053519bdb435a9ed2d8621f22e", null ],
    [ "STACK", "Task_8h.html#a665b9dfb6bb436fd41ca15628ce7b3cb", null ],
    [ "StackHi", "Task_8h.html#afd7c77a4b332d7aa7f8620503f6787f2", null ],
    [ "StackLow", "Task_8h.html#abb40b5e25f8b09c2d5faa915bf7553a2", null ],
    [ "State2Txt", "Task_8h.html#ad149620b5e12343772a3631f2e128441", null ],
    [ "SwitchCount", "Task_8h.html#a7dba0c0136fd223ba0df3b4a6c837200", null ],
    [ "Tasks", "Task_8h.html#aab243e360771aa3dcf46cb3ca687a254", null ]
];