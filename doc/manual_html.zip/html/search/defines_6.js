var searchData=
[
  ['popall',['popall',['../TaskSwitch_8h.html#a75736d8377302454457d0b6287b8e8b5',1,'popall():&#160;TaskSwitch.h'],['../TaskSwitchDemo_8h.html#a75736d8377302454457d0b6287b8e8b5',1,'popall():&#160;TaskSwitchDemo.h']]],
  ['pushall',['pushall',['../TaskSwitch_8h.html#a3ab2d8db832098ad27b998928f6152c6',1,'pushall():&#160;TaskSwitch.h'],['../TaskSwitchDemo_8h.html#a3ab2d8db832098ad27b998928f6152c6',1,'pushall():&#160;TaskSwitchDemo.h']]]
];
