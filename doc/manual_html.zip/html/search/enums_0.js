var searchData=
[
  ['state',['State',['../Task_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8',1,'State():&#160;Task.h'],['../TaskSwitchDemo_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8',1,'State():&#160;TaskSwitchDemo.h']]],
  ['state2',['State2',['../Task_8h.html#aa279f78236faac6b561f1d6589355a30',1,'State2():&#160;Task.h'],['../TaskSwitchDemo_8h.html#aa279f78236faac6b561f1d6589355a30',1,'State2():&#160;TaskSwitchDemo.h']]]
];
