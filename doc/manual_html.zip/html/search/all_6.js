var searchData=
[
  ['getting_20started',['Getting started',['../start.html',1,'']]]
];
