var searchData=
[
  ['setserial',['setSerial',['../classmySerial.html#ae371df237c6e3878fca46aee2ff7ffda',1,'mySerial']]],
  ['setup',['setup',['../CoopOS__Stack__MT__Nano_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'CoopOS_Stack_MT_Nano.ino']]],
  ['stackprepare',['StackPrepare',['../Task_8h.html#af55d11391fca3dd7c3579f1d4842d198',1,'Task.h']]],
  ['stop_5ftask',['stop_task',['../TaskSwitch_8h.html#a7e43f16153ae05541a468062c1e5cf13',1,'stop_task(uint8_t t):&#160;TaskSwitch.h'],['../TaskSwitchDemo_8h.html#a821c2f4021b7f0e06bb827b25b18eb9a',1,'stop_task(uint8_t tn):&#160;TaskSwitchDemo.h']]],
  ['stopme',['stopMe',['../TaskSwitch_8h.html#a9887033f4678ad6ba112b565ebebd632',1,'stopMe():&#160;TaskSwitch.h'],['../TaskSwitchDemo_8h.html#a9887033f4678ad6ba112b565ebebd632',1,'stopMe():&#160;TaskSwitchDemo.h']]]
];
