var searchData=
[
  ['max_5ftasks',['MAX_TASKS',['../CoopOS__Stack__MT__Nano_8ino.html#aac747bed84189f8cfa509b94d488e622',1,'MAX_TASKS():&#160;CoopOS_Stack_MT_Nano.ino'],['../TaskSwitchDemo_8h.html#aac747bed84189f8cfa509b94d488e622',1,'MAX_TASKS():&#160;TaskSwitchDemo.h']]],
  ['myserial',['MySerial',['../DoPrep_8h.html#ac8ed26746a0b3bbe69a795e7b623c7b2',1,'DoPrep.h']]],
  ['mystackfree',['myStackFree',['../TaskSwitch_8h.html#a0fd93743f3e960ee12ed729d185fe51e',1,'TaskSwitch.h']]]
];
