var searchData=
[
  ['task',['task',['../structtask.html',1,'']]]
];
