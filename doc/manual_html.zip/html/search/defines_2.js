var searchData=
[
  ['delay',['Delay',['../TaskSwitch_8h.html#adc6ecf84d6ad6485282766e504fcd54f',1,'Delay():&#160;TaskSwitch.h'],['../TaskSwitchDemo_8h.html#a92c83d3932fc78fda4a9dd7be764940e',1,'Delay():&#160;TaskSwitchDemo.h']]]
];
