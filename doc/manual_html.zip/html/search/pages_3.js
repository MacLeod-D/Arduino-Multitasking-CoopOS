var searchData=
[
  ['intertask_20communication',['Intertask Communication',['../comm.html',1,'']]],
  ['initializing_20tasks',['Initializing Tasks',['../init.html',1,'']]],
  ['introduction',['Introduction',['../intro.html',1,'']]]
];
