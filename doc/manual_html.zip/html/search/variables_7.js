var searchData=
[
  ['name',['name',['../structtask.html#ab607fba9fa5be37990264688187e7021',1,'task']]],
  ['new_5ftask',['new_task',['../structtask.html#a518212cd79d1ab3d77ce0b6ea9b8d4ba',1,'task']]],
  ['number_5fof_5ftasks',['number_of_tasks',['../Task_8h.html#af3d271053519bdb435a9ed2d8621f22e',1,'number_of_tasks():&#160;Task.h'],['../TaskSwitchDemo_8h.html#af3d271053519bdb435a9ed2d8621f22e',1,'number_of_tasks():&#160;TaskSwitchDemo.h']]]
];
