var searchData=
[
  ['oldmicros',['oldMicros',['../TaskSwitch_8h.html#a9c7f8d895cf2554fbd10550d3dab7235',1,'TaskSwitch.h']]],
  ['oldtasks',['oldTasks',['../TaskSwitch_8h.html#af979228e30748b99b4095241de165e0b',1,'TaskSwitch.h']]],
  ['outbuf',['OutBuf',['../MySerial_8h.html#a123feac6b554ccbb501a5039f990f863',1,'MySerial.h']]]
];
