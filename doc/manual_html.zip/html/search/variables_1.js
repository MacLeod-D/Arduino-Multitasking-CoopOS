var searchData=
[
  ['current_5ftask',['current_task',['../Task_8h.html#a9f471ed1586651af36428513ada2706b',1,'current_task():&#160;Task.h'],['../TaskSwitchDemo_8h.html#a9f471ed1586651af36428513ada2706b',1,'current_task():&#160;TaskSwitchDemo.h']]]
];
