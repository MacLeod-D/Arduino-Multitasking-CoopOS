var searchData=
[
  ['del',['DEL',['../Task_8h.html#aa279f78236faac6b561f1d6589355a30a11563127ec3be864b514a1784c5d37a6',1,'DEL():&#160;Task.h'],['../TaskSwitchDemo_8h.html#aa279f78236faac6b561f1d6589355a30a11563127ec3be864b514a1784c5d37a6',1,'DEL():&#160;TaskSwitchDemo.h']]]
];
