var searchData=
[
  ['idle_5fstlen',['IDLE_STLEN',['../CoopOS__Stack__MT__Nano_8ino.html#a13a5f9206b1df56cf6e78bace277681a',1,'IDLE_STLEN():&#160;CoopOS_Stack_MT_Nano.ino'],['../TaskSwitchDemo_8h.html#a13a5f9206b1df56cf6e78bace277681a',1,'IDLE_STLEN():&#160;TaskSwitchDemo.h']]]
];
