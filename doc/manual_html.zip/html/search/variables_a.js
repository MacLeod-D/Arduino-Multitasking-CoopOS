var searchData=
[
  ['serhead',['SerHead',['../MySerial_8h.html#ac2f79a65ac9d058695f09e5d372904a6',1,'MySerial.h']]],
  ['sertail',['SerTail',['../MySerial_8h.html#ab3b3ad48bc7e70ba20b7efc2aa28cbcc',1,'MySerial.h']]],
  ['sp_5fsave',['sp_save',['../structtask.html#a0c19ae47b96c819447ed90112c792a23',1,'task']]],
  ['sreg',['Sreg',['../TaskSwitch_8h.html#a3f1444f11b87794dc372d2a8705b929c',1,'TaskSwitch.h']]],
  ['stack',['STACK',['../Task_8h.html#a665b9dfb6bb436fd41ca15628ce7b3cb',1,'STACK():&#160;Task.h'],['../TaskSwitchDemo_8h.html#a1a8d68b61888304aa3dce983c6136316',1,'STACK():&#160;TaskSwitchDemo.h']]],
  ['stackhi',['StackHi',['../Task_8h.html#afd7c77a4b332d7aa7f8620503f6787f2',1,'StackHi():&#160;Task.h'],['../TaskSwitchDemo_8h.html#a83c3ca30876e515ed156522ebceefaf0',1,'StackHi():&#160;TaskSwitchDemo.h']]],
  ['stacklen',['stackLen',['../structtask.html#af07aa691ab40afb8543956e52813ae93',1,'task']]],
  ['stacklow',['StackLow',['../Task_8h.html#abb40b5e25f8b09c2d5faa915bf7553a2',1,'StackLow():&#160;Task.h'],['../TaskSwitchDemo_8h.html#ad0d24dd3a9533b251636576fd5b6de4e',1,'StackLow():&#160;TaskSwitchDemo.h']]],
  ['state',['state',['../structtask.html#a38f098f1aca88a9cc3982ccc109bcadc',1,'task']]],
  ['state2',['state2',['../structtask.html#a9615bc2dcadf48dd466abf3f80740366',1,'task']]],
  ['state2txt',['State2Txt',['../Task_8h.html#ad149620b5e12343772a3631f2e128441',1,'State2Txt():&#160;Task.h'],['../TaskSwitchDemo_8h.html#ad149620b5e12343772a3631f2e128441',1,'State2Txt():&#160;TaskSwitchDemo.h']]],
  ['switchcount',['SwitchCount',['../Task_8h.html#a7dba0c0136fd223ba0df3b4a6c837200',1,'SwitchCount():&#160;Task.h'],['../TaskSwitchDemo_8h.html#a9fe05a29872ae900ab346ef2a87723e7',1,'SwitchCount():&#160;TaskSwitchDemo.h']]]
];
