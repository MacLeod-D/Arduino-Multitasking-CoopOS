var searchData=
[
  ['ser_5fbuf_5fmax',['SER_BUF_MAX',['../MySerial_8h.html#a9734d6bc7e5e118c96ecf2f7b4f65040',1,'MySerial.h']]],
  ['stackalloc',['STACKALLOC',['../CoopOS__Stack__MT__Nano_8ino.html#a1f698f6139a17ad0214120c976c2e299',1,'STACKALLOC():&#160;CoopOS_Stack_MT_Nano.ino'],['../CoopOS__Stack__MT__Nano_8ino.html#a1f698f6139a17ad0214120c976c2e299',1,'STACKALLOC():&#160;CoopOS_Stack_MT_Nano.ino'],['../TaskSwitchDemo_8h.html#a1f698f6139a17ad0214120c976c2e299',1,'STACKALLOC():&#160;TaskSwitchDemo.h']]],
  ['stackfree',['stackFree',['../TaskSwitch_8h.html#a233a893defdb6ccb299fdba22a69931d',1,'TaskSwitch.h']]],
  ['stackinit',['StackInit',['../TaskSwitchDemo_8h.html#afa33aa135054926cc02e1170668ac5e2',1,'TaskSwitchDemo.h']]],
  ['startmultitasking',['StartMultiTasking',['../TaskSwitch_8h.html#a28d6350ba2c6f99d81fbe99760109e9c',1,'StartMultiTasking():&#160;TaskSwitch.h'],['../TaskSwitchDemo_8h.html#a28d6350ba2c6f99d81fbe99760109e9c',1,'StartMultiTasking():&#160;TaskSwitchDemo.h']]]
];
