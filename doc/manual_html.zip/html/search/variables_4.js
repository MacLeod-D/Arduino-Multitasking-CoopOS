var searchData=
[
  ['idlecount',['IdleCount',['../Task_8h.html#ac3f24db1f52f0fd6d2be8034eb1e38d6',1,'IdleCount():&#160;Task.h'],['../TaskSwitchDemo_8h.html#ac3f24db1f52f0fd6d2be8034eb1e38d6',1,'IdleCount():&#160;TaskSwitchDemo.h']]]
];
