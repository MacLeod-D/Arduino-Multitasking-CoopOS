var searchData=
[
  ['prio',['prio',['../structtask.html#a6c49728507d56dfdfa7c7c6f0e029621',1,'task']]]
];
