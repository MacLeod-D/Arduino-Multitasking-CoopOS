var searchData=
[
  ['rdy',['RDY',['../Task_8h.html#aa279f78236faac6b561f1d6589355a30a79574f1d0a2f78eff42042e34b72436d',1,'RDY():&#160;Task.h'],['../TaskSwitchDemo_8h.html#aa279f78236faac6b561f1d6589355a30a79574f1d0a2f78eff42042e34b72436d',1,'RDY():&#160;TaskSwitchDemo.h']]],
  ['read',['read',['../classmySerial.html#a95c09f04c36c584a4fa488fe88984daa',1,'mySerial']]],
  ['ready',['READY',['../Task_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a6564f2f3e15be06b670547bbcaaf0798',1,'READY():&#160;Task.h'],['../TaskSwitchDemo_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a6564f2f3e15be06b670547bbcaaf0798',1,'READY():&#160;TaskSwitchDemo.h']]],
  ['resume_5ftask',['resume_task',['../TaskSwitch_8h.html#a2e5fff29c8f6f9759605ccd85a94f872',1,'resume_task(uint8_t t):&#160;TaskSwitch.h'],['../TaskSwitchDemo_8h.html#a61240a6fa8fbf5b98b0d2e93e8e10839',1,'resume_task(uint8_t tn):&#160;TaskSwitchDemo.h']]],
  ['run',['RUN',['../Task_8h.html#aa279f78236faac6b561f1d6589355a30a439c688a4e9ed31638d5922a50680a8e',1,'RUN():&#160;Task.h'],['../TaskSwitchDemo_8h.html#aa279f78236faac6b561f1d6589355a30a439c688a4e9ed31638d5922a50680a8e',1,'RUN():&#160;TaskSwitchDemo.h']]]
];
