var structtask =
[
    [ "Delay", "structtask.html#adbb1c6954e3e43d9885cc7b5a925678b", null ],
    [ "function", "structtask.html#a93fb5e9f8aacdbc44d0c4139437144c9", null ],
    [ "lastCalled", "structtask.html#ae4c9cbd7cac0dfb0c7c2ec3d763fbbce", null ],
    [ "name", "structtask.html#ab607fba9fa5be37990264688187e7021", null ],
    [ "new_task", "structtask.html#a518212cd79d1ab3d77ce0b6ea9b8d4ba", null ],
    [ "prio", "structtask.html#a6c49728507d56dfdfa7c7c6f0e029621", null ],
    [ "sp_save", "structtask.html#a0c19ae47b96c819447ed90112c792a23", null ],
    [ "stackLen", "structtask.html#af07aa691ab40afb8543956e52813ae93", null ],
    [ "state", "structtask.html#a38f098f1aca88a9cc3982ccc109bcadc", null ],
    [ "state2", "structtask.html#a9615bc2dcadf48dd466abf3f80740366", null ],
    [ "task_stack", "structtask.html#ab8cb57efe7d3e1b97315f6b1431f52be", null ]
];