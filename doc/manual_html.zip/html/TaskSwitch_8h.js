var TaskSwitch_8h =
[
    [ "Delay", "TaskSwitch_8h.html#adc6ecf84d6ad6485282766e504fcd54f", null ],
    [ "myStackFree", "TaskSwitch_8h.html#a0fd93743f3e960ee12ed729d185fe51e", null ],
    [ "popall", "TaskSwitch_8h.html#a75736d8377302454457d0b6287b8e8b5", null ],
    [ "pushall", "TaskSwitch_8h.html#a3ab2d8db832098ad27b998928f6152c6", null ],
    [ "stackFree", "TaskSwitch_8h.html#a233a893defdb6ccb299fdba22a69931d", null ],
    [ "StartMultiTasking", "TaskSwitch_8h.html#a28d6350ba2c6f99d81fbe99760109e9c", null ],
    [ "freeRam", "TaskSwitch_8h.html#aac7b29dc45caaaca67299571f6a2dcc0", null ],
    [ "Idle", "TaskSwitch_8h.html#a2242f9428023ff0aacadb5fa210a6686", null ],
    [ "memSearch", "TaskSwitch_8h.html#a3fffdb6941bd3b628d53b320661b1751", null ],
    [ "resume_task", "TaskSwitch_8h.html#a2e5fff29c8f6f9759605ccd85a94f872", null ],
    [ "stop_task", "TaskSwitch_8h.html#a7e43f16153ae05541a468062c1e5cf13", null ],
    [ "stopMe", "TaskSwitch_8h.html#a9887033f4678ad6ba112b565ebebd632", null ],
    [ "TaskInit", "TaskSwitch_8h.html#a827fd8dd8b4182d2693a93c5bd712f14", null ],
    [ "TaskSwitch", "TaskSwitch_8h.html#ab193ea1d36a77882a2aa938f7bba3947", null ],
    [ "Yield", "TaskSwitch_8h.html#a2a66f7ffc1635ebc3aa118d246de679f", null ],
    [ "Flag", "TaskSwitch_8h.html#aa4052243b0be641aab93b17feccf3bbe", null ],
    [ "oldMicros", "TaskSwitch_8h.html#a9c7f8d895cf2554fbd10550d3dab7235", null ],
    [ "oldTasks", "TaskSwitch_8h.html#af979228e30748b99b4095241de165e0b", null ],
    [ "Sreg", "TaskSwitch_8h.html#a3f1444f11b87794dc372d2a8705b929c", null ],
    [ "YActive", "TaskSwitch_8h.html#a618cf6560250e3d32388c29d8073166c", null ]
];