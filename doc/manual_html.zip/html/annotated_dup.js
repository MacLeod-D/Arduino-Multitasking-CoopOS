var annotated_dup =
[
    [ "mySerial", "classmySerial.html", "classmySerial" ],
    [ "task", "structtask.html", "structtask" ]
];